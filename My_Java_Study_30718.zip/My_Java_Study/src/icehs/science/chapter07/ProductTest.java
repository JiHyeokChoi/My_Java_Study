package icehs.science.chapter07;

public class ProductTest {

	public static void main(String[] args) {
		Product mix = new Product("Ŀ�ǹͽ�", 12000, 20 );
		
		Product cup = new Product("������", 3000);
		mix.printProductInfo();
		cup.printProductInfo();

	}

}
