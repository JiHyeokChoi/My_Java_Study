package icehs.science.chapter07;

public class Person {
	static int NUMBER_OF_PERSONS = 0;
	String name;
	
}
