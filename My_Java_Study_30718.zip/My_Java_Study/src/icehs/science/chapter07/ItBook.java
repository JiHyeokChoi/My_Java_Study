package icehs.science.chapter07;

public class ItBook {
		private String title;
		private int price;
		private double discountRate;
		
		
		public ItBook(String title, int price, double discountRate) {
			this.title = title;
			this.price = price;
			this.discountRate = discountRate;			
		}
		
		
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			
		}
		public int getPrice() {
			return price;
		}
		public void setPrice(int price) {
			
		}
		public double getDiscountRate() {
			return discountRate;
		}
		public void setDiscountRate(double ditcountRate) {
			
		}
		public void printlnItBookInfo(){
			int lastprice = (int)(price - price * discountRate / 100);
			System.out.println("제목 : " + this.title + ", 정가 : " + this.price + "원, 할인율 : " + this.discountRate + " %, 할인가 : " + lastprice + " 원");
		}
		
			
			
			
		
}
