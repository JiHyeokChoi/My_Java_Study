package icehs.science.chapter07;

public class ItBookTest {

	public static void main(String[] args) {
		ItBook book1 = new ItBook("SQL Plus", 50000, 5.5);
		ItBook book2 = new ItBook("Java 2.0", 28000, 3.2);
		ItBook book3 = new ItBook("JSP Servle", 37000, 6.9);
		
		book1.printlnItBookInfo();
		book2.printlnItBookInfo();
		book3.printlnItBookInfo();
		
		System.out.println("");
		
		System.out.println("SQL Plus 정가와 힐인율을 변경합니다.");
		
		book1 = new ItBook("SQL Plus", 55000, 9.5);
		
		book1.printlnItBookInfo();
		
		System.out.println("");
		
		System.out.println("Java 2.0 정가를 변경합니다.");
		
		book2 = new ItBook("Java 2.0", 33000, 3.2);
		
		book2.printlnItBookInfo();
		
		System.out.println("");
		
		System.out.println("Jsp Servlet 제목과 힐인율을 변경합니다.");
		
		book3 = new ItBook("Servlet & JSP", 37000, 12.6
				);
		
		book3.printlnItBookInfo();
	
	}

}
