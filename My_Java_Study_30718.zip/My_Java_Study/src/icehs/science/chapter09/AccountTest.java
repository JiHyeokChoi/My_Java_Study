package icehs.science.chapter09;

import icehs.science.chapter10.FundAccount;

public class AccountTest {

	public static void main(String[] args) {
		FundAccount[] funAcc = { 
				new FundAccount("111-222", "홍길동", 5000000, 4.7),
				new FundAccount("666-777", "홍길은", 1000000, 2.9) 
				
		};
		
		for(int i = 0 ; i < funAcc.length ; i ++) {
			funAcc[i].openAccount();
			funAcc[i].earnMoney();
			
		}
		/*fundAcc.setName("홍길동");
		fundAcc.setNumber("111-2222");
		fundAcc.setBalance(5000000);	*/	
		

	}

}
