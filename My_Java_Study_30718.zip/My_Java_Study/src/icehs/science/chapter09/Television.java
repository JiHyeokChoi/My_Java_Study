package icehs.science.chapter09;

public class Television extends Product {
	public Television(String name, int price, int discountRate) {
		super(name, price, discountRate);
		this.description = description;
	}
	private String description;

	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
