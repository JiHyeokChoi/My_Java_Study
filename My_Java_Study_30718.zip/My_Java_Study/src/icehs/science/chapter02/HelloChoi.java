package icehs.science.chapter02;

public class HelloChoi {
	public static void main(String[] args) {
		System.out.println("안녕하세요? 최지혁님");
				
	}

}
