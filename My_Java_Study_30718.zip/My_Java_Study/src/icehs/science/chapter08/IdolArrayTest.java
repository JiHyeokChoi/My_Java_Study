package icehs.science.chapter08;

public class IdolArrayTest {

	public static void main(String[] args) {
		
		Idol[] Idols = new Idol[4];
		
		Idols[0] = new Idol("소녀시대", "태연");
		Idols[1] = new Idol("시스타", "보라");
		Idols[2] = new Idol("빅뱅", "지드래곤");
		Idols[3] = new Idol("비스트", "양요섭");
		
		for(int i = 0; i < Idols.length ; i++ ) {
			System.out.println(Idols[i].getGroup() + " : " + Idols[i].getName());
			
		}
		
		/*System.out.println(Idols[0].getGroup() + " : " + Idols[0].getName());
		System.out.println(Idols[1].getGroup() + " : " + Idols[1].getName());
		System.out.println(Idols[2].getGroup() + " : " + Idols[2].getName());
		System.out.println(Idols[3].getGroup() + " : " + Idols[3].getName());*/
		
	}

}
