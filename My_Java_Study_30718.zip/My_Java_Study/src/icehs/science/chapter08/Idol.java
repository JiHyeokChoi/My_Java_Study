package icehs.science.chapter08;

public class Idol {
	private String group;
	private String name;
	
	
	
	
	public Idol(String group, String name) {
		this.group = group;
		this.name = name;
	}


	public String getGroup() {
		return group;
	}


	public String getName() {
		return name;
	}
	
}




	