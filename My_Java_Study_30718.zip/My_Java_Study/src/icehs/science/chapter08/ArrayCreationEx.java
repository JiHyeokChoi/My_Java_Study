package icehs.science.chapter08;

public class ArrayCreationEx {

	public static void main(String[] args) {
		
		int [] lottoNumbers;
		String[] names;
		
		lottoNumbers = new int[6];
		names = new String[10];
		
		int [] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		String [] name = { "홍길동", "이순신", "강감찬"} ;
		
		System.out.println( lottoNumbers[0]);
		System.out.println( arr[3]);
		System.out.println( names[1]);
		System.out.println( name[2]);
		//System.out.println( lottoNumbers[1]);		
		//System.out.println( names[9]);

	}

}
