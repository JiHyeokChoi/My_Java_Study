package icehs.science.chapter05;

public class GuGu3DanTest {

	public static void main(String[] args) {
		int dan = 3;
		for(int i = 1; i < 10; i++) {
			System.out.println(dan + "*" + i + "*" + dan*i);
		}

	}

}
