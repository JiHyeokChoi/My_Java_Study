package icehs.science.chapter05;

public class ForEx {

	public static void main(String[] args) {
		int sum = 0;
		for (int inx = 1; inx <= 100; inx ++) {
			System.out.println(++inx);
			
			
		}
	}

}
