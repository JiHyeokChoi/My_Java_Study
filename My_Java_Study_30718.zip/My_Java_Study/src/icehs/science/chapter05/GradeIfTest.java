package icehs.science.chapter05;

public class GradeIfTest {

	public static void main(String[] args) {
		int gilldongScore = 92;
		int gillsoonScore = 85;
		
		if(gilldongScore >=90) {
			System.out.println("ȫ�浿 : A���� �Դϴ�.");
		}
		if( gillsoonScore >=90 ){
			System.out.println("ȫ��� : A���� �Դϴ�.");
		}
		

	}

}
