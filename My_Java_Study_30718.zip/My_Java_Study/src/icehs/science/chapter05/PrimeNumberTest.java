package icehs.science.chapter05;

public class PrimeNumberTest {

	public static void main(String[] args) {
		int num1 = 23;
		int num2 = 26;
		

	}

}
