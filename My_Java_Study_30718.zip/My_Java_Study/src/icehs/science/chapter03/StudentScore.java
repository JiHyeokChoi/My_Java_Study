package icehs.science.chapter03;

public class StudentScore {

	public static void main(String[] args) {
		double mathScore = 94.7;
		int intmathScore = (int)mathScore;
		double engScore = 83.2;
		int intengScore = (int)engScore;
		double korScore = 87.1;
		int intkorScore = (int)korScore;
		
		System.out.println("수학 : " + intmathScore);
		System.out.println("영어 : " + intengScore);
		System.out.println("국어 : " + intkorScore);

	}

}
