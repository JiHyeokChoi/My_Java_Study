package icehs.science.chapter03;

public class VariablePHelpEx {

	public static void main(String[] args) {
		
		int a1234;
		int first;
		int classone;
		//int var;
		int var;
		int number = 5;
		
		System.out.println( number );
	}

}
