package icehs.science.chapter03;

public class TestScore {

	public static void main(String[] args) {
		int javaScore = 100;
		int sqlScore = 80;
		int servletScore = 85;
		
		System.out.println(javaScore);
		System.out.println(sqlScore);
		System.out.println(servletScore);
		 
	}

}
