package icehs.science.chapter03;

public class MyAgeTest {

	public static void main(String[] args) {
		int myBornYear = 2000;
		int myAge = 19;
		System.out.println(myBornYear);
		System.out.println(myAge);

	}

}
