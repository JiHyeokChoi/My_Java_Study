package icehs.science.chapter03;

public class First_Varialbe {

	public static void main(String[] args) {
		int a = 50;
		System.out.println(a);
		a= 65;
		System.out.println(a);;
	}

}
