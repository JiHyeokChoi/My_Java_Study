package icehs.science.chapter03;

public class PrimitiveTypeEx {

	public static void main(String[] args) {
		int myAge = 19;
		long billWealth = 7000000000L;
		double pi = 3.1415926535;
		boolean isRight = true;
		
		System.out.println( "내 나이 :" + myAge );
		System.out.println( "빌게이츠의 재산 : " + billWealth );
		System.out.println( "원주율 값 : " + pi);
		System.out.println( "위의 값이 맞나요? : " + isRight );
		

	}

}
