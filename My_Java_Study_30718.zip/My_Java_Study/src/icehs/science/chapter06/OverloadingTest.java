package icehs.science.chapter06;

public class OverloadingTest {

	public static void main(String[] args) {
		Overloading over = new Overloading();
		
		over.addition(100, 100);
		over.addition(121.1, 200);
		over.addition("ANI", "World");
		

	}

}
