package icehs.science.chapter06;

public class Coffee {
	String name;
	int price;
	
	int getPrice(){
		return price;
	}
	
	void printCoffeeInfo() {
		System.out.println(name + " " + price + "��");
	}
}
