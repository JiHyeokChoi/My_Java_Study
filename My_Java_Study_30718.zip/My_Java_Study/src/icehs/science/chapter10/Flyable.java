package icehs.science.chapter10;

public interface Flyable {
	public void fly();
	public void spreadwings();
}
