package icehs.science.chapter10;

public class SuperClass {
	public void methodThird() {
		System.out.println("슈퍼 클래스의 매서드 입니다.");
	}
}
