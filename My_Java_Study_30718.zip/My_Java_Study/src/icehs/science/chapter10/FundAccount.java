package icehs.science.chapter10;

import icehs.science.chapter09.Account;

public class FundAccount extends Account {
	private double earningRate;
	private int calculateRate;
	
	
	
	public FundAccount(String number, String name, int balance, double earningRate) {
		super(number, name, balance);
		this.earningRate = earningRate;
	}
		
	public double getEarningRate() {
		return earningRate;
	}

	public void setEarningRate(double earningRate) {
		this.earningRate = earningRate;
	}
	
	public void openAccount() {
		
		
		System.out.println("펀드 계좌 번호 : " + super.getNumber());
		System.out.println("예금주 : " + super.getName());
		
		
	}
	
	public void earnMoney() {
		System.out.println("수익률" + this.earningRate + "%" + "(원금 : " + super.getBalance() + "원)");
		System.out.println("");
		
	}
	
	public void calculateRate() {
		this.calculateRate = calculateRate;
		calculateRate = (int)super.getBalance() + (int)(super.getBalance() * this.earningRate);
		calculateRate = (int)(this.getBalance() * this.earningRate /100 );
		System.out.println("잔액 : " + calculateRate + "원");
		
	}
}
