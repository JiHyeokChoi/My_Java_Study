
package icehs.science.chapter10;

public class AccountTest {

	public static void main(String[] args) {
		
		Account Acc = new Account("1313-445566", "전우치", 100000);
		FundAccount[] funAcc = { 
				
				new FundAccount("111-222", "홍길동", 5000000, 4.7),
				new FundAccount("666-777", "홍길은", 1000000, 2.9) 
				
		};
		
		Acc.openAccount();
	
		for(int i = 0 ; i < funAcc.length ; i ++) {
			funAcc[i].openAccount();
			funAcc[i].calculateRate();
			funAcc[i].earnMoney();
			
		}
		/*fundAcc.setName("홍길동");
		fundAcc.setNumber("111-2222");
		fundAcc.setBalance(5000000);	*/	
		

	}

}
