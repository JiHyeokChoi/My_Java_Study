package icehs.science.chapter10;

public interface InterfaceTwo {
	public void methodTwo();
}
