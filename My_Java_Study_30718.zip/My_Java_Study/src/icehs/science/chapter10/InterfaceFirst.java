package icehs.science.chapter10;

public interface InterfaceFirst {
	public void methodFirst();
}
