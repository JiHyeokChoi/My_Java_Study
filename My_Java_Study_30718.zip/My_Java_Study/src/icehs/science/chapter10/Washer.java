package icehs.science.chapter10;

public interface Washer {
	public abstract void wash();
}
