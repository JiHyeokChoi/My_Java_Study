package icehs.science.chapter04;

public class TemperatureTest {

	public static void main(String[] args) {
		
		int fahrenheit = 100;
		double celcius = (double)5/9*(fahrenheit - 32);
		
		
		
		System.out.println("ȭ�� :" + fahrenheit);
		System.out.println("���� :" + celcius);
		
		
	}

}
