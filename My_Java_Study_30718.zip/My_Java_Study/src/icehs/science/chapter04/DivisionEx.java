package icehs.science.chapter04;

public class DivisionEx {

	public static void main(String[] args) {
		
		int number1 = 10;
		int number2 = 3;
		
		int divisionResult = number1 / number2;
		int remainderResult = number1 % number2;
		
		System.out.println(number1 + " / " + number2);
		System.out.println( "������ ��� :" + divisionResult);
		System.out.println( "������ :" + remainderResult);

	}

}
