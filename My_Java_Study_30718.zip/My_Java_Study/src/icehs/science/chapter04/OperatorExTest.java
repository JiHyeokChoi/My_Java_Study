package icehs.science.chapter04;

public class OperatorExTest {

	public static void main(String[] args) {
		
		int num1 = 11;
		int num2 = 3;
		boolean flag = false;
		
		System.out.println(num1 + num2);
		System.out.println(num1 - num2);
		System.out.println(num1 * num2);
		System.out.println(num1 / num2);
		System.out.println(num1 % num2);
		System.out.println("Using num1 :" + ++num1);
		System.out.println("Using flag :" + flag);
	}

}
