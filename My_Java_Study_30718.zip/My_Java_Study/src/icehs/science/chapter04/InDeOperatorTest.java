package icehs.science.chapter04;

public class InDeOperatorTest {

	public static void main(String[] args) {
		
		int number1 = 20;
		
		System.out.println(++number1);
		System.out.println(number1++);
		System.out.println(--number1);
		System.out.println(number1--);
	}

}
